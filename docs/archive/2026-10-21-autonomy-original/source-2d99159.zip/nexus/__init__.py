"""Nexus: a minimal coding agent."""

__version__ = "0.1.0"
