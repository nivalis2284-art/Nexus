"""Third-party adapter for Nexus plugin API v1 and local chat HTTP contract.

No dependency on Nexus internals; the host injects a PluginHost-compatible object.
"""
from __future__ import annotations

import json
from typing import Any, Protocol
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, Request, build_opener

SDK_VERSION = '0.1.0'
HOST_BASELINE = 'b73ff103a1bbc53f978487d859cfe9bbde411a87'


class PluginHost(Protocol):
    """Only the public surface used by the reference plugin."""
    @property
    def base_url(self) -> str: ...
    @property
    def data_dir(self) -> Any: ...
    @property
    def settings(self) -> dict: ...
    def save_settings(self, values: dict) -> Any: ...


class NexusHTTPError(RuntimeError):
    def __init__(self, status: int, payload: dict):
        self.status, self.payload = status, payload
        super().__init__(str(payload.get('error', f'Nexus HTTP {status}')))


class ChatClient:
    """Adapter to existing host HTTP endpoints, not an official host SDK.

    Works only with the loopback origin supplied by PluginHost.base_url.
    HTTP errors retain their status so callers can present host validation.
    """
    def __init__(self, base_url: str, timeout: float = 20):
        origin = urlsplit(base_url)
        if (origin.scheme != 'http' or origin.hostname not in ('127.0.0.1', 'localhost', '::1')
                or origin.username or origin.password or origin.path not in ('', '/')
                or origin.query or origin.fragment or not origin.port):
            raise ValueError('Use the loopback HTTP origin supplied by host.base_url')
        self.base_url, self.timeout = base_url.rstrip('/'), timeout
        self.opener = build_opener(ProxyHandler({}))

    def _open(self, method, path, payload=None):
        allowed = {('GET', '/api/ling'), ('POST', '/api/ling/input'), ('GET', '/api/stream')}
        if (method, path) not in allowed:
            raise ValueError('Endpoint outside the chat adapter contract')
        data = json.dumps(payload, ensure_ascii=False).encode() if payload is not None else None
        request = Request(self.base_url + path, data=data, method=method,
                          headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
        return self.opener.open(request, timeout=self.timeout)

    def request(self, method, path, payload=None):
        try:
            with self._open(method, path, payload) as response:
                return json.load(response)
        except HTTPError as error:
            with error:
                body = error.read()
            try:
                value = json.loads(body)
            except ValueError:
                value = {'error': f'Nexus HTTP {error.code}'}
            raise NexusHTTPError(error.code, value) from error

    def snapshot(self):
        return self.request('GET', '/api/ling')

    def send(self, text: str, request_id: str):
        if not text.strip() or not request_id:
            raise ValueError('text and stable request_id are required')
        return self.request('POST', '/api/ling/input', {'text': text, 'request_id': request_id})

    def open_events(self):
        """Caller owns and closes response; SSE data is JSON, comments are heartbeats.

        Subscribe before snapshot to avoid a gap. Reconnect using a fresh snapshot;
        this host stream is not a persistent event log and has no replay cursor.
        """
        return self._open('GET', '/api/stream')
